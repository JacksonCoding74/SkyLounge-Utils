const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check the bot\'s ping'),

  async execute(interaction) {
    const botPing = Math.round(interaction.client.ws.ping);
    const botLatency = interaction.createdTimestamp - Date.now();
    await interaction.reply(`🏓 Pong! Bot Latency: ${botLatency}ms, WebSocket Ping: ${botPing}ms`);
  },
};