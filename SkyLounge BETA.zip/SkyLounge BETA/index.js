const { Client, Intents, Collection, CommandInteractionOptionResolver } = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({ intents: [Intents.FLAGS.GUILDS] });
client.commands = new Collection();

// Bot token - Replace 'YOUR_BOT_TOKEN' with your actual bot token
const token = 'MTExNDM0NDQ1ODYxNjU3Mzk5Mw.Gg1aSz.mJF2N1raBQW3crwqDmuX8lek_XzYm4q0Y-q7Mo';

// Read command files
const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(path.join(__dirname, 'commands', file));
  client.commands.set(command.data.name, command);
}

// Bot is ready
client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);

  // Register slash commands
  const guildId = '1113896016442310657'; // Replace with your server's ID
  const commands = client.commands.map(command => command.data.toJSON());
  client.guilds.cache.get(guildId)?.commands.set(commands)
    .then(() => console.log('Slash commands registered!'))
    .catch(console.error);
});

// Bot receives an interaction
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand()) return; // Ignore non-command interactions

  const command = client.commands.get(interaction.commandName);

  // Execute the command
  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: 'An unknowen error occored, please try again later', ephemeral: true });
  }
});

// Login to Discord with your app's token
client.login(token);